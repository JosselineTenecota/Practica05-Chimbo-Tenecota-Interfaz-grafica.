
package ec.edu.ups.practica5.IDAO;

public interface Prestable {
   //metodos para libro. 
    void prestar();

    void devolver();
}
