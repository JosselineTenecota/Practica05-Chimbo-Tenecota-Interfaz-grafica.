
package ec.edu.ups.practica5.IDAO;

import ec.edu.ups.practica5.Modelo.Usuario;
import java.util.List;


public interface UsuarioIDAO {

    void agregarUsuario(Usuario usuario);

    void actualizarUsuario(Usuario usuario);

    void eliminarUsuario(String identificacion);

    Usuario buscarUsuarioPorId(String id);

    List<Usuario> obtenerTodosUsuarios();
}
