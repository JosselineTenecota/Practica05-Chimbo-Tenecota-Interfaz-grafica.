
package ec.edu.ups.practica5.Controlador;

import ec.edu.ups.practica5.Modelo.Usuario;
import ec.edu.ups.practica5.Modelo.Libro;
import ec.edu.ups.practica5.Modelo.Prestamo;
import ec.edu.ups.practica5.IDAO.LibroIDAO;
import ec.edu.ups.practica5.IDAO.UsuarioIDAO;
import ec.edu.ups.practica5.IDAO.PrestamoIDAO;

public class BibliotecaControlador {
    private LibroIDAO libroDAO;
    private UsuarioIDAO usuarioDAO;
    private PrestamoIDAO prestamoDAO;

    public BibliotecaControlador(LibroIDAO libroDAO, UsuarioIDAO usuarioDAO, PrestamoIDAO prestamoDAO) {
        this.libroDAO = libroDAO;
        this.usuarioDAO = usuarioDAO;
        this.prestamoDAO = prestamoDAO;
    }
   
    public void agregarLibro(Libro libro) {
        libroDAO.agregarLibro(libro);
    }

    public void registrarUsuario(Usuario usuario) {
        usuarioDAO.agregarUsuario(usuario);
    }

    public Libro buscarLibro(String titulo) {
        return libroDAO.buscarLibro(titulo);
    }

    public void prestarLibro(Libro libro, Usuario usuario) {
        if (libro.isDisponible()) {
            Prestamo prestamo = new Prestamo(libro, usuario);
            prestamoDAO.agregarPrestamo(prestamo);
            libro.prestar();
        } else {
            System.out.println("El libro no está disponible");
        }
    }
    
    
}
