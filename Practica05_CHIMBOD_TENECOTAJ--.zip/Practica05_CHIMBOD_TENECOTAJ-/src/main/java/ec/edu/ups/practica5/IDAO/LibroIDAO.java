
package ec.edu.ups.practica5.IDAO;

import ec.edu.ups.practica5.Modelo.Libro;
import java.util.List;


public interface LibroIDAO {

    public void agregarLibro(Libro libro);

    public void actualizarLibro(Libro libro);

    public void eliminarLibro(Libro libro);

    public Libro buscarLibro(String titulo);

    List<Libro> obtenerTodosLibros();
}
