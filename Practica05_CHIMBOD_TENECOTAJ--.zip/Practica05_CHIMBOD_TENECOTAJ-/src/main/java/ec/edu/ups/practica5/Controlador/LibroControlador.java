
package ec.edu.ups.practica5.Controlador;

import ec.edu.ups.practica5.Modelo.Libro;
import ec.edu.ups.practica5.IDAO.LibroIDAO;
import java.util.List;

public class LibroControlador {
    private LibroIDAO libroDAO;
    private Libro libro;

    public LibroControlador(LibroIDAO libroDAO) {
        this.libroDAO = libroDAO;
    }
    
    public void mostrarInformacionLibro(Libro libro) {
        libro.mostrarInformacion();
    }
    
    public void agregarLibro(Libro libro){
        this.libro = libro;
        libroDAO.agregarLibro(libro);
    }
    public Libro buscar(String titulo){
        this.libro = libroDAO.buscarLibro(titulo);
        return this.libro;
    }
    public boolean actualizarLibro(Libro libro){
        Libro telefonoEncontrado = this.buscar(libro.getTitulo());
        if(telefonoEncontrado != null){
            libroDAO.actualizarLibro(libro);
            return true;
        }
        return false;
    }
    public boolean eliminarLibro(Libro libro){
        Libro libroEncontrado = this.buscar(libro.getTitulo());
        if(libroEncontrado != null){
            libroDAO.eliminarLibro(libro);
            return true;
        }
        return false;
    }
    
    public List<Libro> obtenerTodosLibros(){
        return libroDAO.obtenerTodosLibros();
    }    
    
}
