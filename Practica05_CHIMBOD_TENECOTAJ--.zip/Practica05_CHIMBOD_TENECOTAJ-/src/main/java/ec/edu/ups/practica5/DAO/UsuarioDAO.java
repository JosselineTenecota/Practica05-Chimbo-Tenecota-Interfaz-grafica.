
package ec.edu.ups.practica5.DAO;

import ec.edu.ups.practica5.Modelo.Usuario;
import java.util.ArrayList;
import java.util.List;
import ec.edu.ups.practica5.IDAO.UsuarioIDAO;


public class UsuarioDAO implements UsuarioIDAO {

    private static List<Usuario> listaUsuarios = new ArrayList<>();

    @Override
    public void agregarUsuario(Usuario usuario) {
        listaUsuarios.add(usuario);
    }

    @Override
    public void actualizarUsuario(Usuario usuario) {
        for (int i = 0; i < listaUsuarios.size(); i++) {
            Usuario personaGuardada = listaUsuarios.get(i);
            if(personaGuardada.getIdentificacion().equals(usuario.getIdentificacion())){
                listaUsuarios.set(i, usuario);
                break;
            }                        
        }
        
    }

    @Override
    public void eliminarUsuario(String identificacion) {
        for (int i = 0; i < listaUsuarios.size(); i++) {
            Usuario usuario = listaUsuarios.get(i);
            if(usuario.getIdentificacion().equals(identificacion)){
                listaUsuarios.remove(i);
                break;
            }                        
        }
    }

    @Override
public Usuario buscarUsuarioPorId(String id) {
    for(Usuario persona : listaUsuarios){
            if(persona.getIdentificacion().equals(id))
                return persona;
        }
        return null;
}

    @Override
    public List<Usuario> obtenerTodosUsuarios() {
        //muestra usuarios.
        return listaUsuarios;
    }
}
