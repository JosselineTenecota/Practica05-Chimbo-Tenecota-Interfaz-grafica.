
package ec.edu.ups.practica5.DAO;

import ec.edu.ups.practica5.Modelo.Libro;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import ec.edu.ups.practica5.IDAO.LibroIDAO;


public class LibroDAO implements LibroIDAO {

    private List<Libro> listaLibros;  

    public LibroDAO() {
        this.listaLibros = new ArrayList<>();
    }

    @Override
    public void agregarLibro(Libro libro) {
        listaLibros.add(libro);
    }

    @Override
    public void actualizarLibro(Libro libro) {
        for (int i = 0; i < listaLibros.size(); i++) {
            Libro libroGuardado = listaLibros.get(i);
            if (libroGuardado.getTitulo().equals(libro.getTitulo())) {
                listaLibros.set(i, libro);
                break;
            }
        }
    }

    @Override
    public void eliminarLibro(Libro libro) {
        Iterator<Libro> iter = listaLibros.iterator();
        while (iter.hasNext()) {
            Libro libroGuardado = iter.next();
            if (libroGuardado.getTitulo().equals(libro.getTitulo())) {
                iter.remove(); // Utiliza el iterador para eliminar el libro de la lista
                break;
            }
        }
    }

    @Override
    public Libro buscarLibro(String titulo) {
    for (Libro libro : listaLibros) {
        if (libro.getTitulo().equalsIgnoreCase(titulo)) {
            return libro;
        }
    }
    return null;
}

    @Override
    public List<Libro> obtenerTodosLibros() {
        return new ArrayList<>(listaLibros);
    }

}
