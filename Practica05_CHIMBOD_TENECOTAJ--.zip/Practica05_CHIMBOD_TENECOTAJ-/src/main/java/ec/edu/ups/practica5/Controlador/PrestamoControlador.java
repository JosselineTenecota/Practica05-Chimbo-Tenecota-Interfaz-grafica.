
package ec.edu.ups.practica5.Controlador;

import ec.edu.ups.practica5.Modelo.Prestamo;
import ec.edu.ups.practica5.Modelo.Libro;
import ec.edu.ups.practica5.Modelo.Usuario;
import ec.edu.ups.practica5.IDAO.PrestamoIDAO;


public class PrestamoControlador {

    private PrestamoIDAO prestamoDAO;
    private UsuarioControlador usuarioControlador;
    private Prestamo prestamo;
    private Usuario usuario;
    private Libro libro;

    public PrestamoControlador(PrestamoIDAO prestamoDAO, UsuarioControlador usuarioControlador) {
        this.prestamoDAO = prestamoDAO;
        this.usuarioControlador = usuarioControlador;
    }
    
    public boolean eliminar(String tituloLibro, String idUsuario) {
        prestamoDAO.eliminarPrestamo(idUsuario, tituloLibro);
        return true;  
    }

    public Prestamo buscarPrestamo(String tituloLibro, Usuario usuario) {
        this.prestamo = prestamoDAO.buscarPrestamo(libro, tituloLibro);
        return this.prestamo;
    }

    public boolean actualizarPrestamo(String tituloLibro, Usuario usuario) {
        Prestamo prestamoEncontrado = this.buscarPrestamo(tituloLibro, usuario);

        if (prestamoEncontrado != null) {
            if (!prestamoEncontrado.esPrestamoVigente()) {
                System.out.println("Error!");
                return false;
            }

            prestamoEncontrado.devolver();  
            prestamoDAO.actualizarPrestamo(prestamoEncontrado);
            return true;
        }
        return false;
    }    
}
