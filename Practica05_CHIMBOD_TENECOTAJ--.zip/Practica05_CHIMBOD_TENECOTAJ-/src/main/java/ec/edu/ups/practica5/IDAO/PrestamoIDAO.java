
package ec.edu.ups.practica5.IDAO;

import ec.edu.ups.practica5.Modelo.Libro;
import ec.edu.ups.practica5.Modelo.Prestamo;
import java.util.List;

public interface PrestamoIDAO {

    void agregarPrestamo(Prestamo prestamo);

    void actualizarPrestamo(Prestamo prestamo);

    void eliminarPrestamo(String idUsuario, String tituloLibro);

    Prestamo buscarPrestamo(Libro libro, String idUsuario);

    List<Prestamo> obtenerTodosPrestamos();
}
