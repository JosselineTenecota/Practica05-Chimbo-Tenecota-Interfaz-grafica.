
package ec.edu.ups.practica5.Controlador;

import ec.edu.ups.practica5.Modelo.Libro;
import ec.edu.ups.practica5.Modelo.Usuario;
import ec.edu.ups.practica5.IDAO.UsuarioIDAO;


public class UsuarioControlador {
    private UsuarioIDAO usuarioDAO;
    private Usuario usuario;

    public UsuarioControlador(UsuarioIDAO usuarioDAO) {
        this.usuarioDAO = usuarioDAO;
    }

    public void registrarUsuario(Usuario usuario) {
       
        this.usuario = usuario;
        usuarioDAO.agregarUsuario(usuario);
    }

    public void solicitarPrestamo(Usuario usuario, Libro libro) {
        usuario.solicitarPrestamo(libro);
    }

    public void devolverLibro(Usuario usuario, Libro libro) {
        usuario.devolverLibro(libro);
    }

    public Usuario buscarUsuarioPorId(String id) {
        this.usuario = usuarioDAO.buscarUsuarioPorId(id);
        return this.usuario;
    }
    
    public boolean actualizar(Usuario usuario){
        Usuario personaEncontrada = this.buscarUsuarioPorId(usuario.getIdentificacion());
        if(personaEncontrada != null){
            usuarioDAO.actualizarUsuario(usuario);
            return true;
        }
        return false;
    }
    public boolean eliminar(String id){
        Usuario usuario = this.buscarUsuarioPorId(id);
        if(usuario != null){
            usuarioDAO.eliminarUsuario(id);
            return true;
        }
        return false;
    }
}
 
